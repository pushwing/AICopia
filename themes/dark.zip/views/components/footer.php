<footer class="mt-5 py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="fw-bold fs-5 mb-2" style="color:#fff"><?= esc($settings['site_name'] ?? '') ?></div>
                <p class="small mb-0" style="line-height:1.7"><?= esc($settings['site_desc'] ?? '') ?></p>
            </div>
            <div class="col-md-4">
                <div class="fw-semibold mb-3 small text-uppercase" style="color:#6366f1;letter-spacing:.08em">연락처</div>
                <?php if (!empty($settings['phone'])): ?>
                    <div class="small mb-1"><i class="bi bi-telephone me-2" style="color:#6366f1"></i><?= esc($settings['phone']) ?></div>
                <?php endif; ?>
                <?php if (!empty($settings['email'])): ?>
                    <div class="small mb-1"><i class="bi bi-envelope me-2" style="color:#6366f1"></i><?= esc($settings['email']) ?></div>
                <?php endif; ?>
                <?php if (!empty($settings['address'])): ?>
                    <div class="small"><i class="bi bi-geo-alt me-2" style="color:#6366f1"></i><?= esc($settings['address']) ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="fw-semibold mb-3 small text-uppercase" style="color:#6366f1;letter-spacing:.08em">SNS</div>
                <div class="d-flex gap-3">
                    <?php if (!empty($settings['instagram'])): ?>
                        <a href="<?= esc($settings['instagram']) ?>" target="_blank" class="fs-5"><i class="bi bi-instagram"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['youtube'])): ?>
                        <a href="<?= esc($settings['youtube']) ?>" target="_blank" class="fs-5"><i class="bi bi-youtube"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['blog'])): ?>
                        <a href="<?= esc($settings['blog']) ?>" target="_blank" class="fs-5"><i class="bi bi-rss"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['kakao'])): ?>
                        <a href="<?= esc($settings['kakao']) ?>" target="_blank" class="fs-5"><i class="bi bi-chat-fill"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <hr class="my-4" style="border-color:#1e293b">

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 small">
            <span><?= esc($settings['copyright'] ?? '') ?></span>
            <?php if (!empty($settings['business_num'])): ?>
                <span>사업자번호: <?= esc($settings['business_num']) ?></span>
            <?php endif; ?>
        </div>
    </div>
</footer>
