Autumn Theme (가을) — AICopia 파생 테마
- 설치: public/css/style.css → public/themes/autumn/css/style.css
- 활성화: 관리자 → 사이트설정 → active_theme = autumn
- 이 테마는 중립 default 위에 팔레트만 얹는 "리틴트" 방식이라, default 레이아웃이
  활성 테마의 오버라이드 CSS를 자동 로드한다(themes/default/layouts/main.php).
  구조·컴포넌트·접근성·JS는 default 를 그대로 상속한다.
