Autumn Theme (가을) — AICopia 파생 테마
설치: 관리자 → 사이트설정 → 테마 → ZIP 업로드(테마명: autumn) → 활성화.
리틴트 방식 — 레이아웃이 default CSS(중립 베이스)를 로드한 뒤 autumn 팔레트 CSS를
얹는다. 구조·컴포넌트·접근성·JS는 default 를 그대로 상속한다.
